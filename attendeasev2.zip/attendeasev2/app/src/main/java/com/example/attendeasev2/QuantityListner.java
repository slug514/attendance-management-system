package com.example.attendeasev2;

import java.util.ArrayList;

public interface QuantityListner {
    void onQuantityChange(ArrayList<String> arrayList);

}
