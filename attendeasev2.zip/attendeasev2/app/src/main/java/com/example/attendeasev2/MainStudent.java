package com.example.attendeasev2;

import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;


public class MainStudent extends AppCompatActivity {
    Button button1;
    TextView textView1,textView2,textView3;
    TextInputEditText subj;
    ProgressBar progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_student);
        subj=findViewById(R.id.subj);
        button1=findViewById(R.id.btn_getsub);
        textView1=findViewById(R.id.ssub);
        textView2=findViewById(R.id.spres);
        textView3=findViewById(R.id.stot);
        progressBar=findViewById(R.id.progressBar);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseFirestore db = FirebaseFirestore.getInstance();
                FirebaseUser ud = FirebaseAuth.getInstance().getCurrentUser();
                DocumentReference docRef = db.collection("users").document(ud.getUid());
                String className = "cseA";
                String subject = String.valueOf(subj.getText());
                String studentName = "abbhinav"; // Replace with the current student's name

                final int[] presentDays = {0};
                final int[] totalDays = {0};

                db.collection(className)
                        .document(subject) // Include subject document if applicable
                        .collection("*") // Query all date collections
                        .get()
                        .addOnSuccessListener(querySnapshot -> {
                            if (querySnapshot != null) {
                                totalDays[0] = querySnapshot.size(); // Get total number of days

                                for (DocumentSnapshot dateSnapshot : querySnapshot.getDocuments()) {
                                    List<String> presentStudents = (List<String>) dateSnapshot.get("present"); // Get present students
                                    if (presentStudents.contains(studentName)) {
                                        presentDays[0]++; // Increment count if student is present
                                    }
                                }

                                // Display student attendance
                                int absentDays = totalDays[0] - presentDays[0];
                                Log.d(TAG, "Student: " + studentName + ", Present Days: " + presentDays[0] + ", Absent Days: " + absentDays);
                                textView1.setText(subject);
                                textView2.setText(presentDays[0]);
                                textView3.setText(totalDays[0]);
                                //Toast.makeText(this, "Student: " + studentName + ", Present Days: " + presentDays[0] + ", Absent Days: " + absentDays, Toast.LENGTH_SHORT).show();
                                // ... (Display the results in the UI or perform other actions)
                            } else {
                                Log.d(TAG, "No attendance data found");
                            }
                        })
                        .addOnFailureListener(e -> {
                            Log.w(TAG, "Error getting attendance data", e);
                        });
            }
        });

    }
}